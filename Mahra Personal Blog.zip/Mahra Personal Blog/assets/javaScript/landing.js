//Filter JS
$(document).ready(function (){
$(".filter-item").click(function(){
    const value = $(this).attr("data-filter");
    if (value == "all"){
        $(".posts-Box").show("1000");
    } else{
        $(".posts-Box")
        .not("." + value)
        .hide("1000");
        $(".posts-Box")
        .filter("." + value)
        .show("1000");
    }
});
//active btn
$(".filter-item").click(function (){
    $(this).addClass("active").siblings().removeClass("active");
});
});

//Changing the background color on scroll
let header = document.querySelector("header");

window.addEventListener("scroll" , () => {
    header.classList.toggle("shadow" , window.scrollY > 0);
});

const btnElList = document.querySelectorAll(".btn");
btnElList.forEach(btnEl =>{
    btnEl.addEventListener("click" , () => {
        document.querySelector(".special")?.classList.remove("special");
        btnEl.classList.add("special");
    });
});
//navigation
document.addEventListener("DOMContentLoaded", function () {
    // Get the navigation element by its ID
    const navigation = document.getElementById("navigation");
  
    // An array containing the navigation items
    const navItems = ["Services"];
  
    // Using 'append' method to add items to the navigation
    navItems.forEach((item) => {
      const li = document.createElement("li");
      li.textContent = item;
      navigation.append(li);
    });
  
   
  });
  
  

    