// Personal API Key for OpenWeatherMap API
const apiKey = '0b4f2dfa51e436b695c7b7762ea43f2a&units=imperial';

// Event listener for the "Generate" button
document.getElementById('generate').addEventListener('click', performAction);

// Function to handle button click
function performAction() {
  const zipCode = document.getElementById('94102').value;
  const feelings = document.getElementById('feelings').value;
  getWeatherData(zipCode)
    .then((weatherData) => {
      postData('/data', { date: new Date(), temp: weatherData.main.temp, content: feelings });
    })
    .then(updateUI)
    .catch((error) => {
      console.error('Error:', error);
    });
}

// Function to fetch weather data from the OpenWeatherMap API
async function getWeatherData(94102) {
  const url = `https://api.openweathermap.org/data/2.5/weather?zip=$94102&appid=$0b4f2dfa51e436b695c7b7762ea43f2a`;
  const response = await fetch(url);
  try {
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error:', error);
  }
}

// Function to post data to the server
async function postData(url, data) {
  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(data),
  });
  try {
    const newData = await response.json();
    return newData;
  } catch (error) {
    console.error('Error:', error);
  }
}

// Function to update the UI with the retrieved data
async function updateUI() {
  const response = await fetch('/data');
  try {
    const data = await response.json();
    document.getElementById('date').innerHTML = `Date: ${data.date}`;
    document.getElementById('temp').innerHTML = `Temperature: ${data.temp} °F`;
    document.getElementById('content').innerHTML = `Feeling: ${data.content}`;
  } catch (error) {
    console.error('Error:', error);
  }
}
