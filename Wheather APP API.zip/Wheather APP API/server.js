// Import required packages
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

// Create an instance of the Express app
const app = express();

// Middleware
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(cors());

// Set up the port for the server to listen on
const port = 3000;
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});

// Endpoint to store app data
let projectData = {};

// GET route to return project data
app.get('/data', (req, res) => {
  res.send(projectData);
});

// POST route to add new entry to project data
app.post('/data', (req, res) => {
  const newData = req.body;
  projectData = { ...projectData, ...newData };
  res.send(projectData);
});
